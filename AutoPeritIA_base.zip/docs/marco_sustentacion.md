# 📚 MARCO DE SUSTENTACIÓN DE AutoPeritIA

## 🏛️ 1. Marco Legal y Normativo
- Código Penal de la Nación Argentina: Art. 94 y 84
- Ley Nacional de Tránsito 24.449
- Código Procesal Penal de la Nación
- Normas internas de Policía Científica y protocolo de actuación

## 🧪 2. Marco Técnico-Científico
- Análisis físico-mecánico, inspección estática, croquización técnica

## 🤖 3. Marco Tecnológico
- Python, FastAPI, React, OpenAI, OSM, generación de informes automatizados

## 👁️‍🗨️ 4. Marco Ético y Profesional
- Objetividad, cadena de custodia, claridad en la redacción

## 📍 5. Marco de Aplicación Institucional
- Para uso de peritos, fiscales, docentes y criminalistas en general
